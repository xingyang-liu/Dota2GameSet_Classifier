Dota2Train.csv, Dota2Test.csv: 源数据文件
pre_process.py: 预处理程序
logistic.py: 用逻辑回归进行分类的程序
draw.py: 数据可视化程序，用于报告

执行： 	$python pre_process.py
      	$python logistic.py
	$python draw.py